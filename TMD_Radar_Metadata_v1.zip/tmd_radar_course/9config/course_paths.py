from pathlib import Path

ROOT = r"/content/drive/MyDrive/tmd_radar_course"
ROOT_PATH = Path(ROOT)

RADAR_1000 = str(
    ROOT_PATH
    / "01_data/radar/uf/PHS240@201807201000.uf"
)

RADAR_1030 = str(
    ROOT_PATH
    / "01_data/radar/uf/PHS240@201807201030.uf"
)

DEM = str(
    ROOT_PATH
    / "01_data/dem/raw/wrl_dem_phk1.tif"
)

# IMPORTANT:
# Notebook 07 expects the raw Wyoming text file.
SOUNDING = str(
    ROOT_PATH
    / "01_data/sounding/raw/sounding_cm.txt"
)

PROVINCE_SHP = str(
    ROOT_PATH
    / "01_data/gis/administrative/thailand_provinces.gpkg"
)

PHITS_SHP = str(
    ROOT_PATH
    / "01_data/gis/administrative/phitsanulok_amphoe.gpkg"
)

BASIN_SHP = str(
    ROOT_PATH
    / "01_data/gis/subbasins_phs/phs_subbasins_hybas07.gpkg"
)

RESULTS = str(
    ROOT_PATH
    / "1results"
)

UTM47N = "EPSG:32647"


def results_dir(lesson):
    path = (
        ROOT_PATH
        / "1results"
        / str(lesson)
    )
    path.mkdir(
        parents=True,
        exist_ok=True,
    )
    return str(path)
